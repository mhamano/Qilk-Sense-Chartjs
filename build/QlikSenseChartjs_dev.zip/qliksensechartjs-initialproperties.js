/*global define*/
define( [], function () {
    'use strict';
    return {
			version: 1.0,
			qHyperCubeDef: {
				qDimensions: [],
				qMeasures: [],
				qInitialDataFetch: [{
					qWidth: 6,
					qHeight: 1500
				}]
			}
    }
} );
